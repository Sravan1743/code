from django.urls import path
from.import views

urlpatterns= [ 
    path('index',views.index,name='index')
    path('base/',views.index,name='base')
    path('about/',views.index,name='about')
    path('contact',views.index,name='contact')
    path('events/',views.index,name='events')
    path('booking/',views.index,name='booking')
]

